import React from 'react';

const ItemList = () =>{
    return (
        <div>
            <h1>Here goes the items</h1>
        </div>
    )
}

export default ItemList;