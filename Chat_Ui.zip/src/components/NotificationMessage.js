import React, { Component } from 'react'

export default class NotificationMessage extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             
        }
    }
    
    render() {
        return (
            <div>
                <p>You have a New Message</p>
            </div>
        )
    }
}
