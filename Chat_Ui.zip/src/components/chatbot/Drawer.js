import React from 'react';
import './Drawer.scss'

class Drawer extends React.Component{
    constructor(props){
        super(props);
        this.state={}
    }

 

    render(){
        return(
            <React.Fragment>
                <div class="viewport">
  <header class="header" role="banner">
    
    <nav id="nav" class="nav" role="navigation">
      
      {/* <!-- ACTUAL NAVIGATION MENU --> */}
      <ul class="nav__menu" id="menu" tabindex="-1" aria-label="main navigation" hidden>
        <li class="nav__item"><a href="#" class="nav__link">Home</a></li>
        <li class="nav__item"><a href="#" class="nav__link">Shop</a></li>
        <li class="nav__item"><a href="#" class="nav__link">Blog</a></li>
        <li class="nav__item"><a href="#" class="nav__link">About</a></li>
        <li class="nav__item"><a href="#" class="nav__link">Contact</a></li>
      </ul>
      
      {/* <!-- MENU TOGGLE BUTTON --> */}
      <a href="#nav" class="nav__toggle" role="button" aria-expanded="false" aria-controls="menu">
        <svg class="menuicon" xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 50 50">
          <title>Toggle Menu</title>
          <g>
            <line class="menuicon__bar" x1="13" y1="16.5" x2="37" y2="16.5"/>
            <line class="menuicon__bar" x1="13" y1="24.5" x2="37" y2="24.5"/>
            <line class="menuicon__bar" x1="13" y1="24.5" x2="37" y2="24.5"/>
            <line class="menuicon__bar" x1="13" y1="32.5" x2="37" y2="32.5"/>
            <circle class="menuicon__circle" r="23" cx="25" cy="25" />
          </g>
        </svg>
      </a>
      
      {/* <!-- ANIMATED BACKGROUND ELEMENT --> */}
      <div class="splash"></div>
      
    </nav>
    
  </header>
  
  {/* <!-- DEMO CONTENT --> */}
  <main class="main" role="main">
    <div class="gallery" aria-label="gallery">
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
      <a href="#" class="gallery__item"></a>
    </div>
  </main>
</div>
            </React.Fragment>
        )
    }
}

export default Drawer;