import React from 'react';

const About = () =>{
    return(
        <div><h1>About Us</h1>
        Here you will get to know more about us.      
        </div>
    )
}

export default About;