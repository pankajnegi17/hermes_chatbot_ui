import React from 'react';

const Landing = () =>{
    return(
        <div style={{textAlign:'center'}}><h1> </h1>
               
        </div>
    )
}

export default Landing;