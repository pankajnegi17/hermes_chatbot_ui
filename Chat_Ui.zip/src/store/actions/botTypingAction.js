export const BOT_TYPING_ACTION = 'BOT_TYPING_ACTION';

export const update_botTyping_to_false = {type:BOT_TYPING_ACTION,payload:false};

export const update_botTyping_to_true = {type:BOT_TYPING_ACTION,payload:true};

