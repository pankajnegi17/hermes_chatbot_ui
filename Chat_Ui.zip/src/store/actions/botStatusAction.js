export const BOT_STATUS_ACTION = 'BOT_STATUS_ACTION';

export const update_botStatus_inactive = {type:BOT_STATUS_ACTION,payload:false};

export const update_botStatus_active = {type:BOT_STATUS_ACTION,payload:true};

