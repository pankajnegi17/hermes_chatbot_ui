export const BOT_MESSAGES_LENGTH_ACTION = 'BOT_MESSAGES_LENGTH_ACTION';

export const bot_message_added = {type:BOT_MESSAGES_LENGTH_ACTION,payload:1};


